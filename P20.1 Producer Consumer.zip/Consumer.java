public class Consumer implements Runnable{
   private static final int DELAY = 1; 
   private SyncedQueue queue;
   private int numItems;

   /**
      Constructs a withdraw runnable.
      @param anAccount the account from which to withdraw money
      @param anAmount the amount to withdraw in each repetition
      @param aCount the number of repetitions
   */
   public Consumer(SyncedQueue queue,
         int numItems)
   {
      this.queue = queue;
      this.numItems = numItems;
   }

   public void run()
   {
      try
      {
         for (int i = 1; i <= numItems; i++)
         {
            queue.remove();
            Thread.sleep(DELAY);
         }
      }
      catch (InterruptedException exception) {}
   }
}	 	  	      		   	        	 	
