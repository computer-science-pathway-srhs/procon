public class PCRunner{
    public static void main(String[] args){
        SyncedQueue<String> Shop = new SyncedQueue<String>(5);
        Producer Jim = new Producer(Shop, "Thicc", 10);
        Consumer Jerry = new Consumer(Shop, 15);
        Thread producer = new Thread(Jim);
        Thread consumer = new Thread(Jerry);
        producer.run();
        consumer.run();
    }
}