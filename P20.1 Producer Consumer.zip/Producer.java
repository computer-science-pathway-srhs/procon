public class Producer implements Runnable{
   private static final int DELAY = 1; 
   private SyncedQueue queue;
   private String item;
   private int numItems;

   /**
      Constructs a deposit runnable.
      @param anAccount the account into which to deposit money
      @param anAmount the amount to deposit in each repetition
      @param aCount the number of repetitions
   */
   public Producer(SyncedQueue queue, String item,
         int numItems)
   {
      this.queue = queue;
      this.item = item;
      this.numItems = numItems;
   }

   public void run()
   {
      try
      {
         for (int i = 1; i <= numItems; i++)
         {
            queue.add(item);
            Thread.sleep(DELAY);
         }
      }
      catch (InterruptedException exception) {}
   }
}	 	  	      		   	        	 	
