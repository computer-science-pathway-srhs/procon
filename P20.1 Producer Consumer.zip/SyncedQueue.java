import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.LinkedList;

public class SyncedQueue<T> extends LinkedList<T>{
    private ReentrantLock changeLock;
    private Condition canChange;
    
    
    public SyncedQueue(int bufferSize) {
        super();
        changeLock = new ReentrantLock();
    }
    
    @Override
	public boolean add(T item) {
	    changeLock.lock();
	    try{
	        if(super.size() < 10){
	            System.out.println("Added!");
	            super.addLast(item);
	        }
	        else{
	            System.out.println("cannot add; too many items in queue");
	        }
	    }
	    finally{
	        changeLock.unlock();
	    }
	    return true;
	}
	
	@Override
	public T remove() {
	    changeLock.lock();
	    try{	 	  	      		   	        	 	
	        if(super.size() != 0){
	            System.out.println("Removed!");
	            return super.remove();
	        }
	        else{
	            System.out.println("cannot remove; no items in queue");
	            return null;
	        }
	    }
	    finally{
	        changeLock.unlock();
	    }
	}
}